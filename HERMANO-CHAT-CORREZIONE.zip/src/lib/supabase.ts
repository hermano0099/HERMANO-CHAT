import 'react-native-url-polyfill/auto';
import 'expo-sqlite/localStorage/install';
import { createClient } from '@supabase/supabase-js';

// Expo fornisce EXPO_PUBLIC_* tramite process.env durante il bundling.
// Tipizzazione locale per evitare una dipendenza Node.js non necessaria nell'app.
declare const process: { env: Record<string, string | undefined> };

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const configured = Boolean(url && key && !url.includes('YOUR-PROJECT'));

// La chiave publishable e' pubblica PER DESIGN. La sicurezza viene dalle RLS in Supabase.
// Non usare mai la service_role key nell'app.
export const supabase = createClient(
  configured ? url! : 'https://placeholder.supabase.co',
  configured ? key! : 'placeholder-publishable-key',
  {
    auth: {
      storage: globalThis.localStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  }
);
