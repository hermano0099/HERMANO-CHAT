import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Btn, Empty, Field, HCText } from '../components/UI';
import { supabase } from '../lib/supabase';
import { C } from '../theme/colors';
import type { Restaurant } from '../types/models';

export function MapScreen({ userId }: { userId: string; isAdmin: boolean }) {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [selected, setSelected] = useState<Restaurant | null>(null);
  const [propose, setPropose] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [description, setDescription] = useState('');
  const [lat, setLat] = useState('');
  const [lng, setLng] = useState('');
  const [website, setWebsite] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('restaurants').select('*').eq('status', 'approved').order('sponsored', { ascending: false }).order('name');
    setLoading(false);
    if (error) Alert.alert('HERMANO MAP', error.message);
    else setRestaurants((data || []) as Restaurant[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function submit() {
    const latitude = Number(lat.replace(',', '.'));
    const longitude = Number(lng.replace(',', '.'));
    if (name.trim().length < 2 || address.trim().length < 4 || !lat.trim() || !lng.trim() || !Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
      Alert.alert('Dati incompleti', 'Inserisci nome, indirizzo e coordinate GPS valide.'); return;
    }
    if (website.trim() && !/^https:\/\//i.test(website.trim())) { Alert.alert('Sito', 'Il link deve iniziare con https://'); return; }
    setSending(true);
    const { error } = await supabase.from('restaurants').insert({ name: name.trim(), address: address.trim(), description: description.trim(), latitude, longitude, website: website.trim() || null, submitted_by: userId, status: 'pending', sponsored: false });
    setSending(false);
    if (error) Alert.alert('Invio non riuscito', error.message);
    else {
      setPropose(false); setName(''); setAddress(''); setDescription(''); setLat(''); setLng(''); setWebsite('');
      Alert.alert('Richiesta inviata', 'Il locale comparirà sulla mappa solo dopo la verifica e approvazione del team HERMANO CHAT.');
    }
  }
  function navigateTo(restaurant: Restaurant) {
    const query = encodeURIComponent(`${restaurant.latitude},${restaurant.longitude}`);
    Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${query}`)
      .catch(() => Alert.alert('Impossibile aprire la mappa esterna'));
  }
  return <ScrollView contentContainerStyle={{ padding: 15, paddingBottom: 35 }}>
    <HCText style={{ fontSize: 15, marginBottom: 10 }}>Solo ristoranti controllati e approvati dal nostro team. Le sponsorizzazioni sono indicate separatamente.</HCText>
    <View style={styles.mapContainer}>
      <MapView style={{ flex: 1 }} initialRegion={{ latitude: 41.1171, longitude: 16.8719, latitudeDelta: 0.16, longitudeDelta: 0.16 }}>
        {restaurants.map(r => <Marker key={r.id} coordinate={{ latitude: r.latitude, longitude: r.longitude }} title={r.name} description={r.address} pinColor={r.sponsored ? '#FFB700' : C.blue} onPress={() => setSelected(r)} />)}
      </MapView>
    </View>
    {selected && <View style={styles.card}>
      <HCText style={styles.title}>{selected.name} {selected.sponsored ? ' · Sponsorizzato' : ''}</HCText>
      <HCText muted>{selected.address}</HCText>
      <HCText style={{ marginTop: 7 }}>{selected.description}</HCText>
      <Btn label="Indicazioni stradali" onPress={() => navigateTo(selected)} style={{ marginTop: 10 }} />
    </View>}
    <HCText style={[styles.title, { marginTop: 20 }]}>Ristoranti verificati ({restaurants.length})</HCText>
    {loading && <ActivityIndicator color={C.blue2} />}
    {restaurants.length === 0 && !loading && <Empty message="Non ci sono ancora ristoranti approvati. La mappa si riempirà dopo le verifiche del team." />}
    {restaurants.map(r => <Pressable key={r.id} onPress={() => setSelected(r)} style={styles.item}>
      <View style={styles.pin}><HCText>⌖</HCText></View>
      <View style={{ flex: 1 }}><HCText style={{ fontWeight: '800' }}>{r.name}</HCText><HCText muted>{r.address}</HCText>{r.sponsored && <HCText style={{ color: '#FFC56A', fontSize: 12 }}>Sponsorizzato</HCText>}</View>
      <HCText style={{ color: C.blue2 }}>Vedi ›</HCText>
    </Pressable>)}
    <View style={{ height: 18 }} />
    <Btn muted label={propose ? 'Chiudi proposta' : '+ Proponi un ristorante'} onPress={() => setPropose(p => !p)} />
    {propose && <View style={styles.card}>
      <HCText style={styles.title}>Proponi un ristorante</HCText>
      <HCText muted style={{ marginBottom: 12 }}>Non apparirà finché un amministratore non lo avrà approvato. Copia le coordinate da Apple Maps o Google Maps.</HCText>
      <Field placeholder="Nome del locale" value={name} onChangeText={setName} maxLength={100} />
      <Field placeholder="Indirizzo completo" value={address} onChangeText={setAddress} maxLength={220} />
      <Field placeholder="Descrizione" value={description} onChangeText={setDescription} maxLength={700} multiline />
      <Field placeholder="Latitudine (es. 41.1171)" keyboardType="numbers-and-punctuation" value={lat} onChangeText={setLat} />
      <Field placeholder="Longitudine (es. 16.8719)" keyboardType="numbers-and-punctuation" value={lng} onChangeText={setLng} />
      <Field placeholder="Sito https://... (facoltativo)" autoCapitalize="none" value={website} onChangeText={setWebsite} />
      <Btn label="Invia al team" onPress={submit} busy={sending} />
    </View>}
  </ScrollView>;
}
const styles = StyleSheet.create({
  mapContainer: { height: 280, borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: C.border },
  card: { backgroundColor: C.panel, borderColor: C.border, borderWidth: 1, padding: 15, marginTop: 13, borderRadius: 16 },
  title: { fontSize: 18, fontWeight: '900', marginBottom: 8 },
  item: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, borderBottomWidth: 1, borderColor: C.border },
  pin: { width: 43, height: 43, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center', borderRadius: 15 },
});
