import React, { useCallback, useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, View } from 'react-native';
import { Btn, Field, HCText } from '../components/UI';
import { supabase } from '../lib/supabase';
import { C } from '../theme/colors';

export function ProfileScreen({ userId }: { userId: string }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('username,display_name').eq('id', userId).single();
    if (error) Alert.alert('Profilo', error.message);
    if (data) { setUsername(data.username); setName(data.display_name); }
    const { data: { user } } = await supabase.auth.getUser();
    setEmail(user?.email || '');
  }, [userId]);
  useEffect(() => { load(); }, [load]);
  async function save() {
    const handle = username.trim().toLowerCase().replace(/^@/, '');
    if (!/^[a-z0-9_]{3,25}$/.test(handle) || !name.trim() || name.trim().length > 60) {
      Alert.alert('Dati non validi', 'Username: 3–25 caratteri, lettere minuscole, numeri o _. Nome: 1–60 caratteri.'); return;
    }
    setBusy(true);
    const { error } = await supabase.from('profiles').update({ username: handle, display_name: name.trim() }).eq('id', userId);
    setBusy(false);
    Alert.alert(error ? 'Non salvato' : 'Profilo aggiornato', error?.message || 'Le modifiche sono state salvate.');
  }
  async function signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) Alert.alert('Uscita', error.message);
  }
  return <ScrollView contentContainerStyle={styles.root}>
    <View style={styles.brand}><HCText style={{ fontSize: 44, fontWeight: '900' }}>H</HCText></View>
    <HCText big style={{ textAlign: 'center', marginBottom: 6 }}>Il tuo profilo</HCText>
    <HCText muted style={{ textAlign: 'center', marginBottom: 24 }}>{email}</HCText>
    <HCText style={styles.label}>Nome visualizzato</HCText>
    <Field value={name} onChangeText={setName} maxLength={60} placeholder="Nome e cognome" />
    <HCText style={styles.label}>Username univoco</HCText>
    <Field value={username} onChangeText={setUsername} autoCapitalize="none" maxLength={25} placeholder="nomeutente" />
    <HCText muted style={{ fontSize: 12, marginBottom: 16 }}>Gli altri potranno trovarti cercando il tuo username. Non utilizzare dati privati.</HCText>
    <Btn label="Salva modifiche" busy={busy} onPress={save} />
    <View style={{ height: 18 }} />
    <Btn muted label="Esci dall'account" onPress={signOut} />
    <HCText muted style={{ fontSize: 12, textAlign: 'center', marginTop: 15 }}>HERMANO CHAT · Beta 0.1.0. Nessun acquisto integrato attivo.</HCText>
  </ScrollView>;
}
const styles = StyleSheet.create({ root: { padding: 24, flexGrow: 1 }, brand: { alignSelf: 'center', marginTop: 23, marginBottom: 20, width: 100, height: 100, borderRadius: 25, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' }, label: { fontWeight: '800', marginBottom: 8 } });
