# HERMANO CHAT — base mobile indipendente da Emergent

**Versione:** 0.1 MVP, 18 ottobre 2026. Creato come **nuovo progetto**, senza usare né copiare il codice di Emergent. Non è un'app già pubblicata, né un APK/IPA.

## Cosa contiene già il codice

- App iOS/Android in **React Native / Expo SDK 57**, stile **blu elettrico + bianco**.
- Registrazione/accesso **email + password** con Supabase Auth, sessione persistente.
- Profili, `@username`, ricerca utenti e creazione di chat private.
- **Messaggi testuali reali** su Postgres, caricati da Supabase, con aggiornamento tramite Supabase Realtime.
- Creazione **gruppi** e **canali**, pubblici/privati, ingresso nei pubblici, aggiunta membri tramite username da parte del proprietario.
- **HERMANO MAP**: mappa interattiva, solo locali **approvati**; suggerimento nuovi ristoranti e approvazione/rifiuto dal pannello amministratore.
- **Segnala messaggio**, **blocca utente** (impedisce l'invio nella chat privata) e sblocca.
- Policy RLS per proteggere chat private e contenuti dei gruppi, ruolo amministratore non assegnabile dall'app.

**Da completare prima di un lancio pubblico:** test con 2 account e 2 telefoni, modifiche di UI, invio immagini/voce/documenti, notifiche push, gestione inviti ai privati tramite consenso, moderazione avanzata, cancellazione account, privacy e termini, anti-spam/rate limits, monitoraggio errori, test RLS automatizzati, accessibilità, identificatori store, eventuale chiave Google Maps per Android release, acquisti in-app/abbonamenti conformi alle regole degli store. **Non** implementa crittografia end-to-end. **Nessuna** pubblicità o pagamenti sono attivi. Non è un sostituto di Telegram pronto per migliaia di utenti.

## 1. Prima di avviare: collega il TUO Supabase

1. Apri [Supabase](https://supabase.com/dashboard), entra nel progetto che hai chiamato **HERMANO CHAT**.
2. Apri **SQL Editor**, crea una nuova query e incolla **l'intero file** `supabase/migrations/001_hermano_chat.sql`, poi premi **Run** **una sola volta**. Va eseguito su uno schema senza tabelle omonime. Fai un backup se ne hai già create.
3. In **Authentication > Providers > Email**, controlla l'autenticazione email. Se la conferma email è attiva, verifica il link di conferma prima di fare login.
4. Recupera **Project URL** e **Publishable key** (o, nei vecchi progetti, `anon` public key) da **Project Settings > API Keys** / **Connect**.
5. Duplica `.env.example` in `.env` e sostituisci solo le due variabili:

```env
EXPO_PUBLIC_SUPABASE_URL=https://progetto.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_... 
```

**Non inserire mai la `service_role` key, una secret key, una password o un access token in `.env`, in GitHub o in questa chat.** `.env` è escluso automaticamente da Git con `.gitignore`. Queste variabili Expo sono pubbliche, quindi tutta la sicurezza dipende dalle policy RLS.

## 2. Avvia Expo

Requisiti: Node.js 22.13+ e npm (oppure GitHub Codespaces). Nel terminale della cartella del progetto:

```sh
npm install
npx expo install --fix
npm run start
```

Il comando `start` usa un tunnel Expo per consentire l'apertura dall'iPhone anche quando il server non è sulla stessa rete. Alla prima esecuzione potresti dover consentire l'installazione di `@expo/ngrok`; non è necessario pagare Emergent. Apri il link `exp://...` su iPhone con **Expo Go** (o scansiona QR da un altro dispositivo). La versione di Expo Go deve supportare SDK 57.

Se vuoi partire da un computer sulla stessa rete Wi-Fi usa `npm run start:local`.

**Limite tecnico:** in questo ambiente non è stato possibile scaricare le dipendenze npm, quindi non ho potuto eseguire una prova completa su un dispositivo. I file TypeScript sono stati controllati sintatticamente.

## 3. Salva il progetto nel tuo GitHub `hermano-chat`

**Non ho accesso di scrittura al tuo account GitHub**: il progetto è fornito come ZIP. Per portarlo nel repository esistente puoi usare un computer o **GitHub Codespaces da Safari su iPhone**.

### Metodo iPhone (Codespaces, se disponibile nel tuo account)

1. Scarica lo ZIP, aprilo nell'app **File** dell'iPhone e conservalo.
2. Apri [github.com](https://github.com) e il tuo repository **`hermano-chat`**. Dal pulsante **Code > Codespaces** crea un Codespace (GitHub potrebbe avere limiti o costi in base al piano).
3. Nell'editor web del Codespace, usa **Explorer > Upload Files** per caricare lo ZIP nella radice del repository; se l'editor mobile non permette l'upload, prova **Richiedi sito desktop** da Safari.
4. Nel terminale del Codespace esegui:

```sh
unzip -o hermano-chat-expo.zip
rm hermano-chat-expo.zip
npm install
npx expo install --fix
```

5. Crea il file `.env` nell'editor con l'URL e la chiave **pubblicabile** di Supabase. **Non fare commit di `.env`**.
6. Esegui `npm run start`, apri su iPhone l'URL Expo mostrato nel terminale. Prova con Expo Go.
7. Quando funziona, salva su GitHub:

```sh
git add .
git commit -m "HERMANO CHAT: MVP Expo + Supabase"
git push
```

> Alternativa PC/Mac: estrai lo ZIP nella cartella clonata del repository e usa gli stessi comandi. GitHub non permette normalmente di importare uno ZIP come intero repository premendo semplicemente “Upload files” sulla pagina principale.

## 4. Attiva il pannello amministratore HERMANO MAP

Dopo che avrai creato e confermato un account dentro l'app, vai in Supabase **SQL Editor** ed esegui, sostituendo il tuo username reale:

```sql
insert into public.app_admins(user_id)
select id from public.profiles where username = 'tuo_username';
```

L'username automatico al primo accesso sarà simile a `user_abcd...`: puoi cambiarlo in **Profilo**. Esci e rientra nell'app dopo aver assegnato il ruolo. Gli utenti comuni possono **proporre** ristoranti ma non approvarli, né contrassegnarli come sponsorizzati. I locali pendenti non appaiono sulla mappa pubblica.

## 5. Test minimo obbligatorio

1. Registra utente A e utente B con **email differenti**.
2. Da A cerca l'username di B, apri una chat e scrivi un messaggio.
3. Da B apri la chat e verifica che sia arrivato; chiudi e riapri la app, controllando che rimanga memorizzato.
4. Da A crea un gruppo pubblico: da B entra e manda un messaggio.
5. Da A crea un canale: verifica che B possa leggere **ma non scrivere**.
6. Da B proponi un ristorante e verifica che **non** appaia ancora nella mappa pubblica. Dall'account admin approva e verifica che ora compaia.
7. Verifica che un utente esterno non possa leggere chat private di altri utenti (test RLS).
8. Blocca e sblocca un altro utente e verifica le restrizioni di invio.
9. Prova Internet assente, dati errati, password sbagliate e registrazione con conferma email.

## Monetizzazione futura (NON integrata)

Il download sarà gratuito. Solo **dopo** il primo rilascio e dopo verifiche degli store: funzioni Premium (tramite acquisti in-app conformi alle regole Apple e Google), profili locali sponsorizzati chiaramente etichettati, e annunci rispettosi della privacy. Serviranno un'integrazione pagamenti, un database ordini e un controllo abbonamenti lato server. **Non inserire annunci nelle chat private.**

## Note tecniche / sicurezza

- Per le prime prove usiamo Supabase **Postgres Changes** su `messages`; a scala maggiore preferire **Realtime Broadcast** e test di carico.
- Le policy RLS proteggono in lettura i messaggi dei membri. Le funzioni `SECURITY DEFINER` sono limitate al caso d'uso; **prima del rilascio occorre un audit indipendente**.
- I gruppi privati si raggiungono tramite invito del proprietario; la funzione attuale aggiunge direttamente l'utente, da sostituire con inviti accettabili/rifiutabili.
- Gli utenti sono ricercabili quando registrati; per il lancio serviranno controlli di privacy della ricerca e prevenzione degli abusi.
- La mappa parte da Bari, modificabile nel file `src/screens/MapScreen.tsx`.
- **Logo:** `assets/logo.png` è ricavato da un ritaglio dello screenshot fornito (qualità ridotta). Sostituiscilo con il file originale del tuo logo prima del lancio; `assets/icon.png` è la sua copia destinata all'icona.
- La registrazione e gli elementi di profilo sono in italiano. Eventuali immagini profilo reali e media richiedono Supabase Storage con relative policy.

## Struttura

```
App.tsx                        navigazione base e autenticazione
src/screens/                   schermate Expo
src/lib/supabase.ts            client, autenticazione persistente
src/theme/                     palette
src/types/                     modelli TypeScript
supabase/migrations/001_...sql schema, trigger, RLS, realtime, admin
assets/                        logo e icona provvisori
.env.example                   nomi variabili (non segreti)
```

Fonti tecniche: [Expo SDK 57](https://docs.expo.dev/versions/v57.0.0/), [Supabase Expo](https://supabase.com/docs/guides/getting-started/quickstarts/expo-react-native), [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [Realtime](https://supabase.com/docs/guides/realtime/postgres-changes).
