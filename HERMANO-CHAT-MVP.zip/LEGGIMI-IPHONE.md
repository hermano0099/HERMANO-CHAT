# HERMANO CHAT — Guida per iPhone

Questa cartella è una **prima base tecnica originale** di HERMANO CHAT, non un'esportazione di Emergent.

## 1. Cosa è stato preparato

- App Expo / React Native per **iOS e Android**, stile blu elettrico e bianco.
- Registrazione email/password e profilo pubblico con username.
- Ricerca utenti e avvio di chat private tra **due account reali**.
- Salvataggio di messaggi su Supabase, sottoscrizione Realtime e lettura solo da membri autorizzati.
- Gruppi e canali pubblici/privati, inviti via username, canali a scrittura del proprietario.
- HERMANO MAP: vera mappa e segnaposto dei soli locali approvati, invio di proposte, approvazione admin.
- Segnalazione di singoli messaggi, blocco in chat private, vista admin delle segnalazioni.
- Nessun dato finto nelle chat; download dell'app da rendere **gratuito** quando sarà pubblicata.

## 2. Cosa DEVI fare prima di provarla

Per motivi di sicurezza non ho le credenziali del tuo Supabase. Completa questi passaggi con il tuo account.

### In Supabase

1. Apri il tuo **progetto HERMANO CHAT** su [Supabase](https://supabase.com/dashboard).
2. Se il progetto è vuoto, apri **SQL Editor** e incolla **una volta sola** il contenuto di `supabase/migrations/001_hermano_chat.sql`. Prima di eseguirlo, esamina il contenuto. **NON eseguirlo su un database con tabelle omonime o dati da salvare senza un backup.**
3. Nelle impostazioni del progetto, trova il **Project URL** e la **Publishable key** (`sb_publishable_...`). Copiale nel file `.env` seguendo `.env.example`.
4. **Non inserire mai la chiave `service_role`, `sb_secret_...` o password personali nel codice, in GitHub o in ChatGPT.**
5. In Authentication > Providers, controlla che il login con email sia attivo. Se chiedi la conferma email, ogni tester deve confermare il suo account.
6. Crea e verifica il tuo account personale nell'app, quindi cambia lo username nella sezione **Profilo**.
7. Per assegnarti il ruolo admin, solo dal SQL Editor del tuo Supabase, esegui:

   ```sql
   insert into public.app_admins (user_id)
   select id from public.profiles where username = 'IL_TUO_USERNAME'
   on conflict do nothing;
   ```

   Sostituisci `IL_TUO_USERNAME` con quello impostato in app. Poi chiudi e riapri l'app, così compare la scheda **Admin**.

### Caricamento su GitHub dal tuo iPhone

Il tuo repository `hermano-chat` è già stato creato. **Questo archivio non è stato caricato automaticamente su GitHub**, perché in questa conversazione non ho accesso al tuo account.

- Salva sul tuo iPhone `HERMANO-CHAT-MVP.zip` (l'archivio allegato in chat), in File.
- Per caricare un progetto con cartelle da iPhone, il metodo più facile è **GitHub Codespaces** (se disponibile al tuo account): apri il repository, scegli **Code > Codespaces > Create codespace**, apri il terminale e inserisci i file dell'archivio usando l'esplora file. Non sovrascrivere file esistenti senza backup.
- In alternativa, dal computer puoi estrarre lo ZIP, aprire un terminale nella cartella e collegare il repository esistente (`git remote add origin ...`), verificando prima gli eventuali commit esistenti.
- Prima di fare il commit verifica che `.env` e le chiavi siano escluse da `.gitignore`.

### Avvio in Expo Go

Serve un ambiente con **Node.js 22** (computer o Codespaces); Expo Go sul solo iPhone non esegue il sorgente se non è stato avviato il server di sviluppo.

```bash
npm install
npx expo install --check
npx expo start --tunnel
```

Se Expo chiede di sistemare versioni delle librerie, segui `npx expo install --fix` e conserva i file modificati. Apri il QR/link generato in **Expo Go** (SDK 57). Per testare la chat crea **due account email diversi** su due dispositivi.

## 3. Test fondamentali

1. Iscriviti con Account A; modifica lo username (es. `hermano_admin`).
2. Registrati con Account B, ad esempio `tester_01`.
3. Da A vai a **Cerca** e cerca `tester_01`; crea chat e invia il messaggio `prova 123`.
4. Da B apri la chat, controlla che il messaggio appaia. Rispondi.
5. Chiudi e riapri: i messaggi devono rimanere.
6. Crea gruppo pubblico, entra da B; verifica che un altro utente che non è membro non possa leggere una chat privata.
7. Proponi un ristorante: non deve apparire prima dell'approvazione dal pannello Admin.
8. Verifica che gli utenti normali non possano approvare locali o leggere messaggi di chat altrui.

## 4. Cosa NON è ancora pronto

- Non ho potuto lanciare l'app su un iPhone né verificare realmente un database Supabase (mancano l'accesso e le chiavi, e questo ambiente non può installare pacchetti npm via rete).
- La protezione dei messaggi avviene tramite **RLS e connessione TLS Supabase**; **NON è crittografia end-to-end**.
- Mancano la protezione anti-spam/rate limiting su server, strumenti completi di moderazione e ban, push notifications, file/audio, avatar, backup e gestione robusta degli account, log e monitoraggio.
- La ricerca username non ha debouncing e usa query semplici: da ottimizzare prima di grandi numeri di utenti.
- Per la pubblicazione servono test di sicurezza, informativa privacy, termini, account sviluppatore Apple/Google e alcune configurazioni Maps. Il piano gratuito di Supabase ha limiti che vanno controllati.
- Nessun abbonamento, sponsorizzazione, acquisto in-app o servizio pubblicitario è stato ancora attivato. **Non ci sono entrate automatiche per download gratuito.**
- L'icona `H` negli assets è **temporanea**; potrai sostituirla con il logo ufficiale che hai già disegnato.

## 5. Prezzi

Il codice del progetto qui fornito non richiede Emergent. Usare Expo Go in sviluppo e iniziare sul piano Free di Supabase può non richiedere pagamenti, entro i limiti del servizio. Pubblicazione App Store / Google Play, build, servizi esterni o uso intensivo possono comportare spese.

## 6. Struttura

- `App.tsx` — navigazione essenziale e sessione
- `src/screens/` — chat, accesso, ricerca, mappa, profilo e moderazione
- `src/lib/supabase.ts` — configurazione del client Supabase
- `supabase/migrations/001_hermano_chat.sql` — schema dati, funzioni e RLS
- `.env.example` — solo segnaposto delle chiavi pubblicabili
- `assets/` — icona temporanea da sostituire

---

**Prossimo passo consigliato:** collegare il repository GitHub `hermano-chat` qui a ChatGPT oppure caricare lo ZIP con un ambiente di sviluppo, quindi collegare Supabase in modo sicuro.
