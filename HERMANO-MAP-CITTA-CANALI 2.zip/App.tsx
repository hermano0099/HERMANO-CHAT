import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StatusBar, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import type { Session } from '@supabase/supabase-js';
import { Btn, HCText } from './src/components/UI';
import { configured, supabase } from './src/lib/supabase';
import { AuthScreen } from './src/screens/AuthScreen';
import { InboxScreen } from './src/screens/InboxScreen';
import { DiscoverScreen } from './src/screens/DiscoverScreen';
import { ChatScreen } from './src/screens/ChatScreen';
import { CreateConversationScreen } from './src/screens/CreateConversationScreen';
import { MapScreen } from './src/screens/MapScreen';
import { AdminScreen } from './src/screens/AdminScreen';
import { ProfileScreen } from './src/screens/ProfileScreen';
import { C } from './src/theme/colors';
import type { Conversation, Profile } from './src/types/models';

type Tab = 'chats' | 'discover' | 'map' | 'profile';
type Page = Tab | 'chat' | 'create' | 'admin';

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [checking, setChecking] = useState(true);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [tab, setTab] = useState<Tab>('chats');
  const [page, setPage] = useState<Page>('chats');
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [chatTitle, setChatTitle] = useState('');

  useEffect(() => {
    if (!configured) { setChecking(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setChecking(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      if (!next) { setProfile(null); setIsAdmin(false); setPage('chats'); setTab('chats'); }
    });
    return () => { listener.subscription.unsubscribe(); };
  }, []);

  const loadProfile = useCallback(async () => {
    if (!session?.user.id) return;
    const [{ data: p, error }, { data: a }] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name').eq('id', session.user.id).maybeSingle(),
      supabase.from('app_admins').select('user_id').eq('user_id', session.user.id).maybeSingle(),
    ]);
    if (error) console.warn('Profilo:', error.message);
    setProfile(p as Profile | null);
    setIsAdmin(!!a);
  }, [session?.user.id]);
  useEffect(() => { loadProfile(); }, [loadProfile]);

  function setMain(next: Tab) { setTab(next); setPage(next); setConversation(null); }
  function openChat(conv: Conversation, title: string) { setConversation(conv); setChatTitle(title); setPage('chat'); }
  function back() { setPage(tab); setConversation(null); }

  let screen: React.ReactNode = null;
  if (page === 'chats') screen = <InboxScreen userId={session?.user.id || ''} refreshKey={0} onChat={openChat} />;
  if (page === 'discover') screen = <DiscoverScreen userId={session?.user.id || ''} onChat={openChat} onCreate={() => setPage('create')} />;
  if (page === 'map') screen = <MapScreen userId={session?.user.id || ''} isAdmin={isAdmin} onChat={openChat} />;
  if (page === 'profile' && profile) screen = <ProfileScreen userId={session?.user.id || ''} />;
  if (page === 'chat' && conversation) screen = <ChatScreen key={conversation.id} conversation={conversation} userId={session?.user.id || ''} />;
  if (page === 'create') screen = <CreateConversationScreen userId={session?.user.id || ''} onDone={c => openChat(c, c.title)} onCancel={back} />;
  if (page === 'admin' && isAdmin) screen = <AdminScreen />;
  const hasSubPage = !(['chats', 'discover', 'map', 'profile'] as Page[]).includes(page);

  return <SafeAreaProvider>
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      {!configured ? <View style={styles.center}>
        <HCText big>HERMANO CHAT</HCText>
        <HCText muted style={styles.helper}>Per attivare la registrazione e i messaggi reali, aggiungi nel file .env l'URL e la chiave pubblicabile del tuo progetto Supabase. Consulta README.md.</HCText>
      </View>
        : checking ? <View style={styles.center}><ActivityIndicator size="large" color={C.blue} /><HCText>Connessione...</HCText></View>
          : !session ? <AuthScreen />
            : !profile ? <View style={styles.center}><ActivityIndicator color={C.blue} /><HCText muted style={styles.helper}>Caricamento profilo... Se rimane bloccato, verifica di avere eseguito la migrazione SQL e confermato l'email.</HCText><Btn label="Riprova" onPress={loadProfile} /></View>
              : <>
                <View style={styles.topbar}>
                  {hasSubPage && <Pressable onPress={back} style={styles.back} accessibilityLabel="Indietro"><Text style={styles.topIcon}>‹</Text></Pressable>}
                  <View style={{ flex: 1 }}>
                    <HCText style={{ fontWeight: '900', fontSize: 21, letterSpacing: 0.3 }}>
                      {page === 'chats' ? 'HERMANO CHAT' : page === 'discover' ? 'Cerca' : page === 'map' ? 'HERMANO MAP' : page === 'profile' ? 'Profilo' : page === 'create' ? 'Nuova community' : page === 'admin' ? 'Team HERMANO' : chatTitle || 'Messaggi'}
                    </HCText>
                  </View>
                  {page === 'profile' && isAdmin && <Pressable onPress={() => setPage('admin')} style={styles.adminShortcut}><HCText style={{ fontWeight: '800', fontSize: 12 }}>Team</HCText></Pressable>}
                  <View style={styles.brand}><HCText style={{ fontSize: 23, fontWeight: '900' }}>H</HCText></View>
                </View>
                <View style={{ flex: 1 }}>{screen}</View>
                {!hasSubPage && <View style={styles.bottom}>
                  {([['chats','◉','Chat'],['discover','⌕','Cerca'],['map','⌖','Mappa'],['profile','♙','Profilo']] as [Tab,string,string][]).map(([key, icon, label]) =>
                    <Pressable accessibilityRole="tab" accessibilityState={{ selected: tab === key }} key={key} onPress={() => setMain(key)} style={styles.navItem}>
                      <Text style={{ fontSize: 23, color: tab === key ? C.white : C.muted }}>{icon}</Text>
                      <HCText style={{ fontSize: 12, color: tab === key ? C.white : C.muted, fontWeight: tab === key ? '900' : '500' }}>{label}</HCText>
                    </Pressable>)}
                </View>}
              </>}
    </SafeAreaView>
  </SafeAreaProvider>;
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30, gap: 15 },
  helper: { textAlign: 'center', lineHeight: 23 },
  topbar: { minHeight: 65, paddingHorizontal: 16, flexDirection: 'row', gap: 12, alignItems: 'center', borderBottomColor: C.border, borderBottomWidth: 1 },
  back: { paddingHorizontal: 8 },
  topIcon: { color: C.white, fontSize: 28 },
  adminShortcut: { backgroundColor: C.blue, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 10 },
  brand: { width: 42, height: 42, backgroundColor: C.blue, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  bottom: { flexDirection: 'row', backgroundColor: C.panel, borderTopColor: C.border, borderTopWidth: 1, paddingTop: 9, paddingBottom: 7 },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3 },
});
